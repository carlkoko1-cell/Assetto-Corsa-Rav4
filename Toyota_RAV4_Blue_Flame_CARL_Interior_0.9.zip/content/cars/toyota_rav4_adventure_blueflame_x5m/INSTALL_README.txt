Toyota RAV4 Adventure Blue Flame CARL — Interior revision 0.9

Back up your existing car folder and personal skins/setups. Drag this complete ZIP into Content Manager and install/update the detected car. The internal car ID is unchanged. For manual installation, extract the content/ folder into your Assetto Corsa installation root. Do not extract another content/cars layer inside the cars folder.

Select the car marked Interior 0.9. Refresh its preview if Content Manager caches the old image. The retained donor extended-physics requirement is CSP build 2744. Start with offline practice. Existing physics, collider and sound are preserved.

This update changes the cockpit glass, steering wheel, visual driver rig/animation, native gauge bindings, upholstery/stitching and wheel emblem hierarchy. It contains the previous solid roof, no-crossbar/no-front-plate changes and CARL rear plate. The automatic-transmission driver now keeps both hands on the rim rather than playing the unrelated BMW shift-arm pose; original shift files remain included.

Offline validation is included in VALIDATION_REPORT.json. Assetto Corsa is not installed in the build environment: live gauge motion, glass appearance, driver skinning/glove clearance and CSP behavior still need an in-game check. This is an Adventure-inspired refinement of the supplied cabin, not an exact factory scan.
