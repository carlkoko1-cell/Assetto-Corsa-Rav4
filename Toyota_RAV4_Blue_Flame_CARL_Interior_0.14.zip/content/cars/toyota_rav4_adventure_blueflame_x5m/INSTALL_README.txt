RAV4 Adventure Blue Flame CARL — Interior 0.14

Exit the running AC session before updating. Back up personal skins/setups. Drag the COMPLETE ZIP into Content Manager and INSTALL ALL detected entries: car plus rav4_adventure_mid_10 instrument font. Select Interior 0.14; refresh cached previews and start a new session. Manual install: extract into the Assetto Corsa root, preserving content/cars/ and content/fonts/.

CSP build 2744 remains required. Full CSP Android Auto replaces the navigation-only screen and needs CSP's shared android_auto package. Keep CSP/shared Lua assets current through Content Manager. An explicit dependency card is shown if the interface has not loaded; this is not phone projection.

BLUE GRILLE LEDs NOW USE THE NORMAL HEADLIGHT SWITCH, not Extra B. Existing Extra A fogs are retained.

Includes fitted/clipped door cards with below-glass backing/end returns, dedicated live CSP RPM controller/3D pointer/hood clearance, reflection-free interior glazing, smaller grille modules fitted to the actual crossbar, matte black wheel pockets and full Android Auto configuration. Existing native speed/gear/clock/font, steering animation, BMW tune/audio/collider, Blue Flame body and CARL plate are retained.

Offline checks and complete archive verification passed. AC/CSP runtime is unavailable here: check RPM, screen interactions, actual windows/mirrors and headlight-switched blue LEDs in-game. See VISUAL_REVISION_NOTES.md and VALIDATION_REPORT.json for exact checks and limits.
