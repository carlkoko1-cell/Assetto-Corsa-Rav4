RAV4 Adventure Blue Flame CARL — Interior revision 0.10

Back up your existing car folder and personal skins/setups. Drag this complete ZIP into Content Manager and INSTALL ALL detected entries: the car plus its rav4_adventure_mid_10 instrument font. No individual replacement files are needed. The internal car ID is unchanged. Select Interior 0.10 and refresh cached previews. Manual installation: extract into the Assetto Corsa installation root, preserving both content/cars/ and content/fonts/.

Retained donor requires CSP build 2744. Start in offline practice. Existing engine/drivetrain/transmission/suspension/tyre physics, collider and FMOD audio are preserved. Original online ACI entitlement requirement remains.

New: photo-guided Adventure cabin/controls/orange storage/seat details, raised complete rearview mirror and relocated windshield sensor patch, reference-style Tennessee In the Black CARL plate, and native MID speed/gear/clock bindings with an included font. The source cabin still limits exact factory accuracy and photorealism.

Offline asset, font and motion validation is included in VALIDATION_REPORT.json. Assetto Corsa is unavailable in this build environment: live telemetry, font rendering, driver/glove clearance and CSP behavior remain unverified. Infotainment/HVAC screens are decorative. Preview MID text is manually illustrated offline, not an in-game result. See VISUAL_REVISION_NOTES.md for details and limits.
