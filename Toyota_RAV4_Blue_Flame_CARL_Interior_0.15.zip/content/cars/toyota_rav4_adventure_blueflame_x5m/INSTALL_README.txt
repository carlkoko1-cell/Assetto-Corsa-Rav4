RAV4 Adventure Blue Flame CARL — Interior 0.15

Exit AC before updating. Back up personal skins/setups. Drag the COMPLETE ZIP into Content Manager and INSTALL ALL detected entries: car and rav4_adventure_mid_10 font. Select Interior 0.15 and start a fresh session. Manual install: extract into the AC root, preserving content/cars/ and content/fonts/.

Use current CSP (existing minimum build 2744), with the shared Android Auto assets. Enable Real Mirrors; reset saved mirror adjustments for this car to try the new defaults. Blue grille LEDs follow normal headlights. Extra A fogs are unchanged.

Includes revised opaque/dimming Android Auto screen, direct visual Lua RPM controller, removal of duplicate hanging mirror/sensor pod, rear-horizon mirror aim, brighter glossy Blue Flame and Content Manager Paint Shop body recoloring. Existing door/window repairs, matte rims, Adventure cabin, native MID, driver animation and tune/audio/collider are retained.

Recolor in Content Manager Custom Showroom > Paint Shop > Body paint (includes mirror caps and tailgate trim), then save as a skin.

Offline structural, geometry, preserved-file and mocked Lua tests passed. AC/Pure/CSP and Content Manager runtime are unavailable here; verify screen in tunnels/headlights, RPM motion and mirror view in-game. See VISUAL_REVISION_NOTES.md and VALIDATION_REPORT.json for checks and limits.
