-- Visual-only controller. Does not load or modify the drivetrain physics script.
-- SceneReference:setRotation replaces rotation, preserving pivot translation.
local rpmNode
local screenMesh
local rebind = 0
local needleRPM
local brightness = 2.4
local axis = vec3(0, 0, 1)
local emission = rgb(2.4, 2.4, 2.4)

function script.update(dt)
  dt = math.max(0, math.min(tonumber(dt) or 0, 0.1))
  rebind = rebind - dt
  if not rpmNode or rebind <= 0 then
    -- CSP car visual scripts scope these searches to their associated car.
    rpmNode = ac.findNodes('RAV4_RPM_LIVE')
    screenMesh = ac.findMeshes('RAV4_ENTUNE_SCREEN')
    rebind = 1
  end

  local rpm = tonumber(car.rpm) or 0
  if rpm ~= rpm then rpm = 0 end
  rpm = math.max(0, math.min(rpm, 8000))
  if not needleRPM then needleRPM = rpm end
  needleRPM = needleRPM + (rpm - needleRPM) * (1 - math.exp(-dt / 0.045))
  -- Model-space XY sweep: 0..8000 RPM -> 0..183 degrees from its built-in zero.
  rpmNode:setRotation(axis, math.rad(needleRPM * 183 / 8000))

  -- Opaque emissive display: black pixels remain black. Headlights dim the
  -- backlight for tunnels/night instead of adding a white diffuse/glass layer.
  local target = car.headlightsActive and 1.6 or 2.4
  brightness = brightness + (target - brightness) * (1 - math.exp(-dt / 0.20))
  emission.r, emission.g, emission.b = brightness, brightness, brightness
  screenMesh:setMaterialProperty('ksEmissive', emission)
end
