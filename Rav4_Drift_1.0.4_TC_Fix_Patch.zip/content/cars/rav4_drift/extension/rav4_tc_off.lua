-- Dedicated player-car TC controller; separate from instruments and physics.
-- ac.setTC(0) sets the live TC mode to OFF. Keep it off after session/pit resets.
-- Does not change ABS, stability control, throttle input or other cars.
local warned = false

function script.update(dt)
  if not car or car.index ~= 0 or car.isAIControlled then return end
  if sim and sim.isReplayActive then return end

  if type(ac.setTC) == 'function' then
    if car.tractionControlMode ~= 0 then ac.setTC(0) end
  elseif not warned then
    warned = true
    if type(ac.log) == 'function' then
      ac.log('Rav4 Drift: live TC-off controller requires CSP car-control ac.setTC; set TC Off in driving assists.')
    end
  end
end
