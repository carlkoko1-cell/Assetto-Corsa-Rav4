RAV4 Adventure Blue Flame CARL — Supplied-model interior 0.12

Back up the existing car folder and personal skins/setups. Drag the COMPLETE ZIP into Content Manager and INSTALL ALL detected entries: car plus rav4_adventure_mid_10 instrument font. Select Interior 0.12 and refresh cached previews. Manual installation: extract into the Assetto Corsa root, preserving content/cars/ and content/fonts/.

This update imports the cabin geometry from your 2023 RAV4 Hybrid upload and adapts it with black upholstery, orange stitching/storage details and graphite/satin trim. Dashboard, seats, door panels, console and steering wheel are replaced. Hybrid display graphics are replaced with the Adventure-style native instrument setup. Existing Blue Flame exterior, repaired mirrors/raised rearview mirror, CARL plate, BMW tune/audio and collider are preserved.

CSP build 2744 remains required. Begin in offline practice. The original online ACI entitlement requirement remains.

Offline asset/motion checks passed. AC/CSP runtime is unavailable: live font/mirror rendering and glove/driver clearance require in-game confirmation. Climate/infotainment displays are decorative. The adapted 2023 model still differs from an exact 2019 Adventure. See VISUAL_REVISION_NOTES.md and VALIDATION_REPORT.json.
