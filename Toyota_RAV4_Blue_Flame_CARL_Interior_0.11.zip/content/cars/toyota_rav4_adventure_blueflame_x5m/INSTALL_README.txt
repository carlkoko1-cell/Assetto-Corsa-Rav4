RAV4 Adventure Blue Flame CARL — Interior 0.11

Back up your car folder and personal skins/setups. Drag the COMPLETE ZIP into Content Manager and INSTALL ALL detected entries: car plus rav4_adventure_mid_10 instrument font. Select Interior 0.11 and refresh the cached preview. Manual installation: extract into the Assetto Corsa root, retaining content/cars/ and content/fonts/.

Repairs: remove extra native dashboard text rotation reported to reverse digits; rebuild all three mirror UV projections and optical normals; redraw instrument/climate faces from user close-ups, add raised climate buttons and satin trim adjustment. Existing black/orange Adventure cabin, raised mirror, CARL Tennessee In the Black plate, Blue Flame body and BMW tune/audio are retained.

CSP build 2744 required by the donor. Begin in offline practice. Original online ACI entitlement requirement remains.

Offline validation passed. AC/CSP runtime is unavailable: corrected native digit orientation and live mirror views need in-game confirmation. Climate/infotainment/coolant graphics are decorative. Preview digital fields are deliberately blank. Source-model geometry limits photorealism. See VISUAL_REVISION_NOTES.md and VALIDATION_REPORT.json.
