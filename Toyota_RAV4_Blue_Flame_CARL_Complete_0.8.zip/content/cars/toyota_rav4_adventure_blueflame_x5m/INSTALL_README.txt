TOYOTA RAV4 ADVENTURE — BLUE FLAME CARL — COMPLETE VISUAL REVISION 0.8

Back up your existing toyota_rav4_adventure_blueflame_x5m folder.
Drag the complete ZIP into Content Manager and install/update the detected car.
For manual installation, extract into your Assetto Corsa installation root.
The ZIP already contains content/cars/toyota_rav4_adventure_blueflame_x5m/.
This updates the original RAV4; BMW tune/physics/audio remain preserved.
Requires CSP compatible with the original donor extended-physics build2744.

Features: continuous solid roof; no crossbars; no front plate; black CARL rear
plate; corrected badges; glossy solid Blue Flame material; blue tailgate garnish;
refined cabin, steering, instruments, glass, mirrors, lamps and wiper bindings;
stationary calipers; connected LODs; obsolete donor visual assets removed.

Offline asset checks and Blender inspection performed. No Assetto Corsa runtime
or driving test was possible here. See VISUAL_REVISION_NOTES.md and
VALIDATION_REPORT.json for exact verification and remaining limitations.
This retains the approximate supplied source body/cabin and is not an OEM scan.
