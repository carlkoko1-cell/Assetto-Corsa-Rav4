# Toyota RAV4 Adventure — Blue Flame visual revision 0.7

An actual KN5/model and configuration revision of the ZIP supplied by the owner. The existing BMW X5M performance tune and sound are preserved, as requested. This is a visual improvement of the supplied 2021-based body toward a 2019 Adventure, not a newly scanned OEM replica.

## Install

1. Back up your existing `content/cars/toyota_rav4_adventure_blueflame_x5m` folder, including personal setups/skins.
2. Drag `Toyota_RAV4_Blue_Flame_Visual_Revision_0.7.zip` into Content Manager and install/update the detected car. It uses the **same car ID** as the original supplied release, so this updates that RAV4.
3. Select **Toyota RAV4 Adventure | Blue Flame (Visual Revision 0.7, X5M Tune)** and the Blue Flame skin. Use Assetto Corsa with CSP compatible with the donor car's retained extended-physics requirement (`REQUIRED_VERSION=2744`).
4. Refresh the Content Manager preview if it caches the old image. Start an offline practice session first.

## Changes

- Removed the floating white/red/amber/reverse-light bars. The original projector, headlamp, fog-lamp, taillight, high-mounted brake, turn-signal, and reverse-light surfaces now have separate, correctly named bindings. Beam origins follow the original projectors. Rear clear lenses no longer share the red-lens texture.
- Removed the blocky added dashboard, seats, steering wheel, and trim that obscured the detailed source cabin. Restored more than 45,000 source cabin triangles, mirrored the original right-hand-drive cabin to match the existing left-hand driver, and connected its original wheel to `STEER_HR`.
- Added separate dashboard/plastic/soft upholstery/headliner/carpet finishes, subtle normal-mapped grain, orange Adventure stitching and shelf piping, a fitted Entune-inspired face and bezel labels, physical knobs, vents and climate controls, Toyota wheel emblem, and geometric RPM/speed pointers.
- Restored all three mirror glasses, which the prior revision had mistakenly assigned to the blue body-paint material. Registered individual center/left/right mirror meshes.
- Reworked the solid Blue Flame paint toward Toyota 8W9, with restrained clearcoat/specular settings. The central tailgate garnish shares the exact body texture and material settings; the separate Toyota emblem stays chrome. Roof remains blue.
- Applied consistent cabin orientation, mirror, lamp, and garnish changes to all four LOD models; compacted unused materials/textures and batched small trim details.
- Removed BMW instrument/extra-animation definitions targeting nonexistent display meshes. Updated car/skin metadata and previews.

## Verification and limits

`validation-report.json` records actual offline checks. All four KN5s parse and round-trip losslessly, vertex/index/material references are valid, embedded texture dependencies resolve, generated DDS mip chains are complete, and configured light/mirror/instrument mesh names exist. All 64 nonvisual data files and both sound files are byte-identical to the supplied release. Blender renders were used to inspect placement and occlusion; **these are not in-game screenshots or CSP shader previews**.

Assetto Corsa is not installed in this Linux workspace. Actual CSP light switching, beam behavior, mirror views, needle direction/range, driver hand alignment, sound playback and road behavior have **not** been tested. Screens are decorative and do not provide interactive Entune/HVAC controls or live trip/fuel/temperature information. The existing driver/wiper animation assets were retained, not retargeted. The OEM-style 8,000-rpm/140-mph face can be exceeded by the retained tuned drivetrain. Paint is an sRGB estimate, not a measured 8W9 calibration, and its appearance depends on lighting and the game's PP filter. Original body topology and source LOD simplification remain.

Recommended in-game checks: headlights off/low/high; brake vs. tail intensity; left/right/hazard signals; reverse lamps; all three mirrors; gauge motion at idle and low speed; driver hands while steering; cockpit visibility; LOD transitions; sound and an offline drive. Report screenshots and CSP/PP-filter versions for any remaining visual mismatch.

## Rebuild in the prepared cloud workspace

Python 3 with NumPy, SciPy and Pillow is used for model generation/validation. Blender 4.3 is used for inspection. The original ZIP is kept outside the checkout under `/workspace/scratch`.

```bash
cd /workspace/Assetto-Corsa-Rav4
python3 tools/build_visual_revision.py /workspace/scratch/Toyota_RAV4_Blue_Flame_One_Click_Content_Manager.zip
python3 tools/configure_visual_revision.py
python3 tools/validate_mod.py /workspace/scratch/Toyota_RAV4_Blue_Flame_One_Click_Content_Manager.zip
```

The build always starts from the original model bytes, so revisions do not accumulate transformations. Generated texture sources are in `source_textures/`. `tools/render_inspect.py` supports offline Blender inspection; its material mapping approximates AC shaders. The KN5 binary layout was cross-checked against [AcTools](https://github.com/gro-ove/actools/tree/master/AcTools/Kn5File), and CSP parameter names against [the official configuration examples](https://github.com/ac-custom-shaders-patch/acc-extension-config).

The supplied release's notes are preserved as `SOURCE_RELEASE_NOTES.txt` inside the car folder.
