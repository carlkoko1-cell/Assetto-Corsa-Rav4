TOYOTA RAV4 ADVENTURE - BLUE FLAME - VISUAL REVISION 0.7
======================================================

Updates the supplied v0.6.1 car; BMW X5M tune and sound are preserved.

INSTALL
1. Back up your existing toyota_rav4_adventure_blueflame_x5m car folder.
2. Drag this complete ZIP into Content Manager and install/update the detected car.
3. Select Toyota RAV4 Adventure | Blue Flame (Visual Revision 0.7, X5M Tune).
4. Use compatible CSP and first test in an offline practice session.

The same car folder ID is intentionally retained, so this updates the original RAV4.

CHANGES
- Floating lamp bars removed; original lamp/projector surfaces and beam positions used.
- Detailed source interior restored and converted from RHD to LHD; original wheel animated.
- New interior finishes, screen/cluster graphics, physical knobs, trim and stitching.
- Reflective mirror glasses restored and correctly registered.
- Solid Blue Flame-inspired paint; middle tailgate garnish matches body in every LOD.
- BMW tune, physics, scripts and audio files remain unchanged.

VALIDATION
Offline KN5, texture, configuration, source-preservation checks and Blender inspection passed.
Assetto Corsa/CSP gameplay was NOT tested. The included images are offline Blender renders.
Please verify lighting controls, mirrors, gauge direction, driver hands, sound and driving in game.
Entune and climate screens are decorative, not interactive; no live trip/fuel/temp readout.
Paint is an 8W9-inspired estimate; no claim of colorimetric or factory-scanned accuracy.
The underlying supplied body is 2021-based; existing driver/wiper animations are not retargeted.
The retained tune may exceed the OEM-style 8,000-rpm / 140-mph instrument-face range.

See VISUAL_REVISION_NOTES.md for detailed changes and remaining limitations.
SOURCE_RELEASE_NOTES.txt preserves the original release's description.
