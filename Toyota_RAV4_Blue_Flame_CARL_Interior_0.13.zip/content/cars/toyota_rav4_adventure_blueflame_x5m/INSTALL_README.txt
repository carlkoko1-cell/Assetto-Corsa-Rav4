RAV4 Adventure Blue Flame CARL — Interior 0.13

Back up personal skins/setups. Drag the COMPLETE ZIP into Content Manager and INSTALL ALL detected entries: car plus rav4_adventure_mid_10 instrument font. Select Interior 0.13; refresh cached previews. Manual install: extract into the Assetto Corsa root, preserving content/cars/ and content/fonts/.

CSP build 2744 remains required. BMW-style CSP navigation is adapted from the supplied ASW X5M configuration to the RAV4 screen. Assign CSP Extra B for the four steady blue grille modules; Extra A still controls the existing fogs.

Reference-led cluster/pointer calibration, opaque instrument enclosure and door returns, source-recess climate LCD, raised/refitted rearview mirror, body-painted mirror caps, smoked amber mirror indicators and glass/metal shader changes are included. Existing BMW tune/audio/collider and working steering animation are preserved.

Offline asset checks passed; Assetto Corsa/CSP runtime is unavailable here. Check live digits/navigation, mirrors and night lighting in-game. Climate artwork, economy/ODO placeholders and coolant marker are decorative. This adapted 2023 cabin differs from an exact 2019 Adventure. See VISUAL_REVISION_NOTES.md and VALIDATION_REPORT.json.
